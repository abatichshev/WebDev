import {Album} from "./models";

export const ALBUMS: Album[] = [];
ALBUMS.push(
  {
    id: 1,
    title: `title ${1}`,
    userId: 1
  }
)

ALBUMS.push(
  {
    id: 2,
    title: `title ${2}`,
    userId: 2
  }
)
